This code gave the detailed implementation of ``High-Order Tensor Completion with A Tensor U1 Norm''.
 

The code contains: 
 

DemoBSD_TC_SL.m: TC-SL on BSD [1] at sampling rate p=0.7.

DemoBSD_TC_U1.m: TC-U1 on BSD [1] at sampling rate p=0.7.

TC-PADMM: contains PADMM algorithm for TC-SL and TC-U1. 

LibADMM-master: contains some necessary functions for tensor algebra. [2]

High-order tensor-SVD Toolbox:  contains some necessary functions for high-order tensor algebra. [3]


 
[1] https://www2.eecs.berkeley.edu/Research/Projects/CS/vision/bsds/ 
[2] https://github.com/canyilu/LibADMM-toolbox
[3] Qin, Wenjin, Hailin Wang, Feng Zhang, Jianjun Wang, Xin Luo, and Tingwen Huang. "Low-rank high-order tensor completion with applications in visual data." IEEE Transactions on Image Processing 31 (2022): 2433-2448. 
