


%run in terminal
%lfw_1-50_all.mat
% matlab -nodisplay -nosplash -nodesktop -r "fun_DemoBSD_TC_SL_NSGAii('./','/home/onelong/Longlongaaago/Matlab_workroot/Datasets',{'/lfw_1-50_all.mat'},true,0.3,10,3); exit;"
%
function fun_DemoBSD_TC_SL_NSGAii(target_root, data_root,  data_list,if_rand,sample_ratio,show_img,max_iter)
    disp("running the fun_DemoBSD_TC_SL_NSGAii !!!! ")

    
    if nargin < 7
        max_iter = 30; %  number of iteration
    end 
    if nargin < 6
        show_img = -1; % number of images to save for showing
    end 
    if nargin < 5
        sample_ratio = 0.3; %  
    end
    if nargin < 4
        if_rand = true; % 只有当第三个参数缺失时才设置默认值
    end
    if nargin < 3
        data_list = ['/adience_1_all.mat',  ...
            '/gtdb_1-5_all.mat',    ...
            '/lfw_1-50_all.mat']    
    end
    if nargin < 2
        data_root = './'; % 只有当第二个参数缺失时才设置默认值
    end
    if nargin < 1
        target_root = './'; % 只有当第一个参数缺失时才设置默认值
    end

    disp(['target_root:',target_root,'data_root:',data_root,'data_list:',data_list,'if_rand:',string(if_rand),"sample_ratio:",string(sample_ratio)]);
    disp(['show_img:',string(show_img),'max_iter:',string(max_iter)]); 

    mkdir(target_root);
    res_root = fullfile(target_root, "results/");
    mkdir(res_root);

    temp_list = {};
    for video_num=1:length(data_list)
        temp_list{end+1} = fullfile(data_root,data_list{video_num});
    end
    img_list = temp_list;
    disp(img_list);

    % clear all;clc;
    addpath(genpath(cd))

    for iii=1:length(img_list)
    
        % clear all;clc;
        % addpath(genpath(cd))
        load(img_list{iii});
        data = double(data);
        disp(strcat("data_size",mat2str(size(data))));

        [X, NewSq, invNewSq] = randomizeOrNot(data, if_rand);

        if (max(X(:)) > 1)
            X = X / 255;
        end
        
        maxP = max(abs(X(:)));
        dimX = size(X);
        
        % sampling rate
        p = sample_ratio;
        
        omega = find(rand(prod(dimX), 1) < p);
        omegaall = find(rand(prod(dimX), 1) < 1.1);
        M = zeros(dimX);
        M(omega) = X(omega);
        opts.DEBUG = 0;
        disp(['Start learning of the tensor nuclear norm']);
        [xhatlist,Qlist]=getlistCand(M,omega,opts);
        
        %            opts.mode = [2,3];
        % opts.Hset = [];%[1,4];
        % [Xhat, E, err, iter] = TCSL_PADMM(M, omega, opts);
        % pop(1).Position=Xhat;
        % pop(1).Cost = CostFunction(pop(i).Position,opts);
        %    psnr2 = PSNR_high(X, Xhat, maxP)
        % 
         
        
        %% Problem Definition
        
        CostFunction = @(x,Qlist,opts) evalue_LowRankness(x,Qlist,opts);      % Cost Function 这里需要修改
        
        nVar = 3;             % Number of Decision Variables
        
        VarSize = size(M);   % Size of Decision Variables Matrix 这里需要修改
        
        VarMin = 0;          % Lower Bound of Variables
        VarMax = 1;          % Upper Bound of Variables
        
        % Number of Objective Functions
        nObj = numel(CostFunction(unifrnd(VarMin, VarMax, VarSize),Qlist,opts));
        
        
        %% NSGA-II Parameters
        
        MaxIt = max_iter;      % Maximum Number of Iterations
        
        nPop = 50;        % Population Size
        
        pCrossover = 0.4;                         % Crossover Percentage
        nCrossover = 2*round(pCrossover*nPop/2);  % Number of Parnets (Offsprings)
        
        pMutation = 0.6;                          % Mutation Percentage
        nMutation = round(pMutation*nPop);        % Number of Mutants
        
        % mu = 0.02;                    % Mutation Rate
        mu = 0.05;                    % Mutation Rate

        sigma = 0.1*(VarMax-VarMin);  % Mutation Step Size
        
        tic
        %% Initialization
        disp(['Start Initialization']);
        empty_individual.Position = [];%E
        empty_individual.Cost = [];
        empty_individual.Rank = [];
        empty_individual.DominationSet = [];
        empty_individual.DominatedCount = [];
        empty_individual.CrowdingDistance = [];
        
        pop = repmat(empty_individual, nPop, 1);
        
        for i = 1:nPop
            
            ss=unifrnd(VarMin, VarMax, VarSize);
            ss(omega) = M(omega);
            pop(i).Position = ss;
            
            pop(i).Cost = CostFunction(pop(i).Position,Qlist,opts);
            
        end
        for ii=1:(length(dimX)*(length(dimX)-1)/2) 
         pop(ii).Position=xhatlist{ii};
         pop(ii).Cost = CostFunction(pop(ii).Position,Qlist,opts); 
        psnr2 = PSNR_high(X, xhatlist{ii}, maxP) 
        end
        
        % Non-Dominated Sorting
        [pop, F] = NonDominatedSorting(pop);
        
        % Calculate Crowding Distance
        pop = CalcCrowdingDistance(pop, F);
        
        % Sort Population
        [pop, F] = SortPopulation(pop);
        
        
        %% NSGA-II Main Loop
        disp(['Start NSGA-II Main Loop']);
        for it = 1:MaxIt
            
        
            % Crossover
            popc = repmat(empty_individual, nCrossover/2, 2);
            for k = 1:nCrossover/2
                
                i1 = randi([1 nPop]);
                p1 = pop(i1);
                
                i2 = randi([1 nPop]);
                p2 = pop(i2);
                
                [popc(k, 1).Position, popc(k, 2).Position] = Crossover_tensor(p1.Position, p2.Position, omega,M);
                
                popc(k, 1).Cost = CostFunction(popc(k, 1).Position,Qlist,opts);
                popc(k, 2).Cost = CostFunction(popc(k, 2).Position,Qlist,opts);
                
            end
            popc = popc(:);
            
            % Mutation
            popm = repmat(empty_individual, nMutation, 1);
            for k = 1:nMutation
                
                i = randi([1 nPop]);
                p = pop(i);
                
                popm(k).Position = Mutate_tensor(p.Position, mu, sigma,omega,M);
                
                popm(k).Cost = CostFunction(popm(k).Position,Qlist,opts);
                
            end
            
            % Merge
            pop = [pop
                 popc
                 popm]; %#ok
             
            % Non-Dominated Sorting
            [pop, F] = NonDominatedSorting(pop);
        
            % Calculate Crowding Distance
            pop = CalcCrowdingDistance(pop, F);
        
            % Sort Population
            pop = SortPopulation(pop);
            
            % Truncate
            pop = pop(1:nPop);
            
        for ii=1:(length(dimX)*(length(dimX)-1)/2) 
            pop(ii).Position=xhatlist{ii};
            pop(ii).Cost = CostFunction(pop(i).Position,Qlist,opts); 
            %psnr2 = PSNR_high(X, xhatlist{ii}, maxP) 
        end
        
            % Non-Dominated Sorting
            [pop, F] = NonDominatedSorting(pop);
        
            % Calculate Crowding Distance
            pop = CalcCrowdingDistance(pop, F);
        
            % Sort Population
            [pop, F] = SortPopulation(pop);
            
            % Store F1
            F1 = pop(F{1});
            
            % Show Iteration Information
            disp(['Iteration ' num2str(it) ': Number of F1 Members = ' num2str(numel(F1))]);
            psnr2 = PSNR_high(X, F1(1).Position, maxP)
            %XX=F1(1).Position;
            %X00=X(omega);
            %XX00=XX(omega);
            %mse=norm(X00(:)-XX00(:))^2/(prod(dimX*0.3))
            XX=zeros(dimX);
            for jj=1:length(F1)%min(length(F1),5)
            XX=XX+F1(jj).Position;
            end
            XX=XX/length(F1);%min(5,length(F1));
            XX(omega)=X(omega);
            psnr3 = PSNR_high(X(:, :, :, invNewSq), XX(:, :, :, invNewSq), maxP)
            % Plot F1 Costs
            figure(1);
            PlotCosts(F1);
            pause(0.01);
            if mod(it,50)==0
              [~,Qlist]=getlistCand(XX,omegaall,opts);
           end
        end
        toc 
        %get the name
        split_res = strsplit(img_list{iii},'/');
        video_name = split_res{end};

        filename = strcat(res_root,video_name,'TCSLNSGAii', datestr(now, 'yyyy-mm-dd_HH--MM--SS'), '.mat'); %

        disp("AAA========AAA");
        disp(strcat('<Method:TcsLNSGAii','_$_','time:',datestr(now,'yyyy-mm-dd_HH-MM-SS'),'_$_','data_name:',video_name,'_$_','sample_rate:', ...
        string(sample_ratio),'_$_','psnr3:',string(psnr3),'_$_','psnr2:',string(psnr2), ...
        '_$_','elapsedtime:',string(toc),'_$_','frames:',string( size(X,4))));
        
        save(filename, 'psnr2', "XX", 'psnr3', 'NewSq');
        % rmpath(genpath(cd));

        if show_img>0
            % outputFolder = strcat("./show_img/input_",video_name,string(video_num),'_')
            % SaveImages(Y_, outputFolder,false,30);
            % outputFolder = strcat("./show_img/real_",video_name,string(video_num),'_')
            % SaveImages(X, outputFolder,false,30);
            outputFolder = strcat("./show_img/restore_",video_name,string(video_num),'_')
            SaveImages(XX(:, :, :, invNewSq), outputFolder,false,show_img);
        end
    end
end



function [T, NewSq, invNewSq] = randomizeOrNot(T, randomize)
    % 获取T的第四维大小
    numElements = size(T, 4);
    
    if randomize
        % 如果需要随机排列
        NewSq = randperm(numElements);
    else
        % 如果不需要随机排列，只是生成一个顺序序列
        NewSq = 1:numElements;
    end
    
    % 无论是否随机排列，都计算逆排序索引
    [~, invNewSq] = sort(NewSq);
    
    if randomize
        % 如果需要随机排列，重新排列T的第四维
        T = T(:,:,:,NewSq);
    end
    % 如果不需要随机排列，不改变T，直接返回
end



function SaveImages(data, outputFolder,norm,img_num)
    % 检查输出文件夹是否存在，如果不存在则创建
    if ~exist(outputFolder, 'dir')
        mkdir(outputFolder);
    end

    % 加载MAT文件
    % matData = load(matFilePath);
    % 假设MAT文件中的变量名为data，且其大小为[w, h, c, num]
    % data = matData.data; % 调整变量名以匹配你的实际情况

    if norm==true
        data = double(data) / 255;
    end        

    % 获取帧数
    numFrames = size(data, 4); 
    numFrames = min(img_num,numFrames);
    % 遍历每一帧
    for i = 1:numFrames
        % 提取第i帧
        frame = data(:, :, :, i);

        % 构建输出文件名
        fileName = sprintf('frame_%04d.png', i);
        outputFile = fullfile(outputFolder, fileName);
        % 保存帧为图片
        imwrite(frame, outputFile);
    end
end
