%
% Copyright (c) 2015, Mostapha Kalami Heris & Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "LICENSE" file for license terms.
%
% Project Code: YPEA120
% Project Title: Non-dominated Sorting Genetic Algorithm II (NSGA-II)
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Cite as:
% Mostapha Kalami Heris, NSGA-II in MATLAB (URL: https://yarpiz.com/56/ypea120-nsga2), Yarpiz, 2015.
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
%



clear all;clc;
addpath(genpath(cd))

load('img_data.mat');
dim=size(data);
X=zeros(dim(1),dim(2),3,dim(3)/3); 
 for i=1:50
   X(:,:,:,i)=double(data(:,:,3*(i-1)+1:3*i)); 
 end 
[~, ~, ~, n4] = size(X);
NewSq = randperm(n4);
[~, invNewSq] = sort(NewSq);

X = X(:, :, :, NewSq); 
if (max(X(:)) > 1)
    X = X / 255;
end

maxP = max(abs(X(:)));
dimX = size(X);

% sampling rate
p = 0.3;


omega = find(rand(prod(dimX), 1) < p);
omegaall = find(rand(prod(dimX), 1) < 1.1);
M = zeros(dimX);
M(omega) = X(omega);
opts.DEBUG = 0;
disp(['Start learning of the tensor nuclear norm']);
[xhatlist,Qlist]=getlistCand(M,omega,opts);

 
 


%% Problem Definition

CostFunction = @(x,Qlist,opts) evalue_LowRankness(x,Qlist,opts);      % Cost Function 这里需要修改

nVar = 3;             % Number of Decision Variables

VarSize = size(M);   % Size of Decision Variables Matrix 这里需要修改

VarMin = 0;          % Lower Bound of Variables
VarMax = 1;          % Upper Bound of Variables

% Number of Objective Functions
nObj = numel(CostFunction(unifrnd(VarMin, VarMax, VarSize),Qlist,opts));


%% NSGA-II Parameters

MaxIt = 60;      % Maximum Number of Iterations

nPop = 50;        % Population Size

pCrossover = 0.4;                         % Crossover Percentage
nCrossover = 2*round(pCrossover*nPop/2);  % Number of Parnets (Offsprings)

pMutation = 0.6;                          % Mutation Percentage
nMutation = round(pMutation*nPop);        % Number of Mutants

mu = 0.05;                    % Mutation Rate

sigma = 0.1*(VarMax-VarMin);  % Mutation Step Size


%% Initialization
disp(['Start Initialization']);
empty_individual.Position = [];%E
empty_individual.Cost = [];
empty_individual.Rank = [];
empty_individual.DominationSet = [];
empty_individual.DominatedCount = [];
empty_individual.CrowdingDistance = [];

pop = repmat(empty_individual, nPop, 1);

for i = 1:nPop
    
    ss=unifrnd(VarMin, VarMax, VarSize);
    ss(omega) = M(omega);
    pop(i).Position = ss;
    
    pop(i).Cost = CostFunction(pop(i).Position,Qlist,opts);
    
end
for ii=1:(length(dimX)*(length(dimX)-1)/2) 
 pop(ii).Position=xhatlist{ii};
 pop(ii).Cost = CostFunction(pop(ii).Position,Qlist,opts); 
psnr2 = PSNR_high(X, xhatlist{ii}, maxP) 
end

% Non-Dominated Sorting
[pop, F] = NonDominatedSorting(pop);

% Calculate Crowding Distance
pop = CalcCrowdingDistance(pop, F);

% Sort Population
[pop, F] = SortPopulation(pop);


%% NSGA-II Main Loop
disp(['Start NSGA-II Main Loop']);
for it = 1:MaxIt
    

    % Crossover
    popc = repmat(empty_individual, nCrossover/2, 2);
    for k = 1:nCrossover/2
        
        i1 = randi([1 nPop]);
        p1 = pop(i1);
        
        i2 = randi([1 nPop]);
        p2 = pop(i2);
        
        [popc(k, 1).Position, popc(k, 2).Position] = Crossover_tensor(p1.Position, p2.Position, omega,M);
        
        popc(k, 1).Cost = CostFunction(popc(k, 1).Position,Qlist,opts);
        popc(k, 2).Cost = CostFunction(popc(k, 2).Position,Qlist,opts);
        
    end
    popc = popc(:);
    
    % Mutation
    popm = repmat(empty_individual, nMutation, 1);
    for k = 1:nMutation
        
        i = randi([1 nPop]);
        p = pop(i);
        
        popm(k).Position = Mutate_tensor(p.Position, mu, sigma,omega,M);
        
        popm(k).Cost = CostFunction(popm(k).Position,Qlist,opts);
        
    end
    
    % Merge
    pop = [pop
         popc
         popm]; %#ok
     
    % Non-Dominated Sorting
    [pop, F] = NonDominatedSorting(pop);

    % Calculate Crowding Distance
    pop = CalcCrowdingDistance(pop, F);

    % Sort Population
    pop = SortPopulation(pop);
    
    % Truncate
    pop = pop(1:nPop);
    
for ii=1:(length(dimX)*(length(dimX)-1)/2) 
 pop(ii).Position=xhatlist{ii};
 pop(ii).Cost = CostFunction(pop(i).Position,Qlist,opts); 
%psnr2 = PSNR_high(X, xhatlist{ii}, maxP) 
end


    % Non-Dominated Sorting
    [pop, F] = NonDominatedSorting(pop);

    % Calculate Crowding Distance
    pop = CalcCrowdingDistance(pop, F);

    % Sort Population
    [pop, F] = SortPopulation(pop);
    
    % Store F1
    F1 = pop(F{1});
    
    % Show Iteration Information
    disp(['Iteration ' num2str(it) ': Number of F1 Members = ' num2str(numel(F1))]);
    psnr2 = PSNR_high(X, F1(1).Position, maxP)
    %XX=F1(1).Position;
    %X00=X(omega);
    %XX00=XX(omega);
    %mse=norm(X00(:)-XX00(:))^2/(prod(dimX*0.3))
    XX=zeros(dimX);
    for jj=1:length(F1)%min(length(F1),5)
    XX=XX+F1(jj).Position;
    end
    XX=XX/length(F1);%min(5,length(F1));
    XX(omega)=X(omega);
    psnr3 = PSNR_high(X, XX, maxP)
    % Plot F1 Costs
    figure(1);
    PlotCosts(F1);
    pause(0.01);
   if mod(it,50)==0
     [xhatlist,~]=getlistCand(XX,omegaall,opts);
   end
end

%% Results
%psnr2 = PSNR_high(X, F1(1).Position, maxP)
%psnr2 = PSNR_high(X, F1(2).Position, maxP)
%psnr2 = PSNR_high(X, F1(3).Position, maxP)
%psnr2 = PSNR_high(X, F1(4).Position, maxP)
%psnr2 = PSNR_high(X, F1(5).Position, maxP)
%psnr1 = PSNR_high(X, M, maxP)
%psnr2 = PSNR_high(X(:, :, :, invNewSq), Mhat(:, :, :, invNewSq), maxP)
% 