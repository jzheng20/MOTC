function htnn= PCASL_PADMM(M,opts)



tol = 1e-5;
max_iter = 300; 
rho_mu = 1.05;
rho_eta = 1.05; 
mu = 10 ^ (-4);
eta = 10 ^ (-4);
 

max_mu = 1e14;
max_eta = 1e14;
DEBUG = 0;
if ~exist('opts', 'var')
    opts = [];
end
 
if isfield(opts, 'tol');         tol = opts.tol;              end
if isfield(opts, 'max_iter');    max_iter = opts.max_iter;    end
if isfield(opts, 'rho');         rho = opts.rho;              end
if isfield(opts, 'mu');          mu = opts.mu;                end
if isfield(opts, 'max_mu');      max_mu = opts.max_mu;        end
if isfield(opts, 'DEBUG');       DEBUG = opts.DEBUG;          end

Hset=opts.Hset;
mode=opts.mode;
dim = size(M);
h = length(dim);
%omegac = setdiff(1:prod(dim),omega);

Z = randn(dim);
X=randn(dim); 
E = zeros(dim);
Y = E;
Q=cell(1,h);
for i=1:h
    if ismember(i,Hset) 
   Q{i}= eye(dim(i)); %dftmtx(dim(i))/sqrt(dim(i)); %dct(eye(dim(i)));%eye(dim(i)); %
    else 
        Q{i}=eye(dim(i)); %dftmtx(dim(i))/sqrt(dim(i));%eye(dim(i)); % dct(eye(dim(i)));%
    end
end
 % L = dftmtx(n3); trransform.l = n3; transform.L = L;
% L = dct(eye(n3)); transform.l = 1; transform.L = L;
% L = RandOrthMat(n3); transform.l = 1; transform.L = L;
 
for iter = 1 : max_iter
    Zk = Z;
    Ek = E;
    Qk = Q;
    Xk=X;

    %update Z and Q 
     [Z,Q,X]=PBCD_inner(M-E+Y/mu,Z,Q,mu,eta,Hset,mode);
      X= real(X);


    % update E  
    E = zeros(dim);
   % E(omega) = 0;
    
    dY = M-X-E;


    tempchgQ=[];
   for k=h:-1:1
   dQ=Q{k}-Qk{k};
   tempchgQ(k) =max(abs(dQ(:)));
   end
    chgQ=max(tempchgQ);
    chgZ = max(abs(Zk(:)-Z(:)));
    chgE = max(abs(Ek(:)-E(:)));
     chgX = max(abs(Xk(:)-X(:)));
    chg = max([chgZ chgE chgQ chgX max(abs(dY(:)))]);
   % mse(iter)=norm(Z(:)-originZ(:),'fro')/norm(originX(:),'fro');
    
    if DEBUG
        if iter == 1 || mod(iter, 50) == 0
            err = norm(dY(:));
            disp(['iter ' num2str(iter) ', mu=' num2str(mu) ...
                ', err=' num2str(err)]);
        end
    end
    
    if chg < tol 
        break;
    end
    Y = Y + mu*dY;
    mu = min(rho_mu*mu,max_mu);
    eta = min(rho_eta*eta,max_eta);

end

err = norm(dY(:));

[~,htnn,~] = cal_tensornorm_FFT(Y,mode);
 