function [xhatlist,Qlist]=getlistCand(M,omega,opts)

dim=length(size(M));
xhatlist=cell(1,dim*(dim-1)/2);%zeros(dim,dim);
Qlist=cell(dim,dim-1);
tt=0;
for i=1:dim
    for j=i+1:dim 
        tt=tt+1;
 opts.Hset = [i,j];
 opts.mode = []; 
for t=1:dim
  if ~ismember(t,opts.Hset)
   opts.mode = [opts.mode t]; 
  end
end
[Xhat, ~, Q, ~, ~] = TCSL2_PADMM(M, omega, opts); 
xhatlist{tt}=Xhat;
Qlist{i,j}=Q; 
    end
end

