function [Z,Q,ZQ]=PBCD_inner(P,Zk,Q,lambda,mu0,Hset,Lmode)
dim = size(P);
h = length(dim);
%update Z
UP=P;
for k=1:h
    if ~ismember(k,Lmode)
        UP=tmprod(UP,Q{k},k);
    end
end
if  isempty(Lmode)
    Z=soft((lambda*UP+mu0*Zk)/(mu0+lambda),1/(mu0+lambda));
else
    Z=prox_sliceswise_FFT((lambda*UP+mu0*Zk)/(mu0+lambda),Lmode,1/(mu0+lambda));
end

% update Q_fft
for t=1:h
    if ismember(t,Hset)
        tempA=Z;
        for k=h:-1:t+1
            tempA=tmprod(tempA,Q{k}',k);
        end
        tempB=P;
        for k=1:t-1
            tempB=tmprod(tempB,Q{k},k);
        end
        unA=[sqrt(lambda)*Unfold(tempA, size(tempA),t) sqrt(mu0)*Q{t}];
        unB=[sqrt(lambda)*Unfold(tempB, size(tempB),t) sqrt(mu0)*eye(dim(t),dim(t))];
        [U,S,V]=svd(unA*unB');
        Q{t}=U*V';
    end
end


ZQ=Z;
for k=h:-1:1
    ZQ=tmprod(ZQ,Q{k}',k);
end
