%
% Copyright (c) 2015, Mostapha Kalami Heris & Yarpiz (www.yarpiz.com)
% All rights reserved. Please read the "LICENSE" file for license terms.
%
% Project Code: YPEA120
% Project Title: Non-dominated Sorting Genetic Algorithm II (NSGA-II)
% Publisher: Yarpiz (www.yarpiz.com)
% 
% Developer: Mostapha Kalami Heris (Member of Yarpiz Team)
% 
% Cite as:
% Mostapha Kalami Heris, NSGA-II in MATLAB (URL: https://yarpiz.com/56/ypea120-nsga2), Yarpiz, 2015.
% 
% Contact Info: sm.kalami@gmail.com, info@yarpiz.com
%

function htnn = evalue_LowRankness(x,Qlist,opts)

 
dim=length(size(x));
htnn=[];%zeros(dim,dim);

for i=1:dim
    for j=i+1:dim 
 opts.Hset = [i,j];
 opts.mode = []; 
for t=1:dim
  if ~ismember(t,opts.Hset)
   opts.mode = [opts.mode t]; 
  end
end
ux=x;
Q=Qlist{i,j};
for k=1:dim 
    if ~ismember(k,opts.mode)
        ux=tmprod(ux,Q{k},k);
    end
end
[~,htnni,~] = cal_tensornorm_FFT(ux,opts.mode);
%htnni= PCASL_PADMM(x,opts);
htnn=[htnn; htnni];
%Xhat=M;
%toc

    end
end

   % z = [z1 z2]';
end 
