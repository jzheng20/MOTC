% Developer: Jingjing Zheng jjzheng233@gmail.com  

function [y1, y2] = Crossover_tensor(x1, x2, omega,obx)

    alpha = rand(size(x1));
    
    
    y1  = alpha.*x1+(1-alpha).*x2;
    y2 = alpha.*x2+(1-alpha).*x1;

    y1(omega)=obx(omega); 
    y2(omega)=obx(omega);
end