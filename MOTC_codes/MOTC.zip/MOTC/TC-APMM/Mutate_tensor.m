 
% Developer: Jingjing Zheng jjzheng233@gmail.com  

function y = Mutate_tensor(x, mu, sigma,omega,obx)

    nVar = numel(x);
    
    nMu = ceil(mu*nVar);
   for ss=1:100

    j = randsample(nVar, nMu);
    if numel(sigma)>1
        sigma = sigma(j);
    end
    
    y = x;
    
    y(j) = x(j)+sigma.*randn(size(j));

   end
    y(omega)=obx(omega);  
end